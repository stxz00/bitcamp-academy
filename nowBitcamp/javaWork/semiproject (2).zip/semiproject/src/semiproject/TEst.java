package semiproject;

import java.io.IOException;
import java.io.ObjectInputStream;

public class TEst {
public static void main(String[] args) throws IOException {
	System.out.println("test1");
	new ObjectInputStream(System.in);
	System.out.println("test2");
}
}
