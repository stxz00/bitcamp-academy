package man;

public class Client {

}
